A Pen created at CodePen.io. You can find this one at http://codepen.io/kieranfivestars/pen/JdbPBv.

 If the animation was removed this would be a very simple mobile navigation that I use regularly, but everyone loves animation on CodePen!