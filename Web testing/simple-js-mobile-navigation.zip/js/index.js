$("i").click(function () {
  $("ul").toggleClass("open");
});